
def main():
	return 5+6


if __name__ == "__main__":
		import sys
		ret=main()
		sys.exit(ret)